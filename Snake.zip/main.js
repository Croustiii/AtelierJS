const canvas = document.querySelector('#canvas')
const scoreSpan = document.querySelector('.score')
const boutton = document.querySelector('.replay')
let score = 0

const context = canvas.getContext('2d')

const background = new Image()
background.src = 'fond-bleu2.jpg'

const foodImg = new Image()
foodImg.src  = 'food2.png'

const snakeHead = new Image()
snakeHead.src = 'snake_head.png'

const snake_body = new Image()
snake_body.src = 'snake_body.png'

const eatAudio = new Audio()
eatAudio.src = 'eat.mp3'

const deadAudio = new Audio()
deadAudio.src = 'dead.mp3'

const unit = 30

let food = {
    x:Math.floor(Math.random() *19+1)*unit,
    y:Math.floor(Math.random() *19+1)*unit
}

snake = []
snake[0] = {
    x:10*unit,
    y:10*unit
}

//deplacement avec le clavier
let Deplacement
document.addEventListener('keydown', (e)=>{
    if(e.keyCode == 37 && Deplacement !="R"){
        Deplacement = "L"
    }
    else if(e.keyCode == 38 && Deplacement !="D"){
        Deplacement = "U"
    }
    else if(e.keyCode == 39 && Deplacement !="L"){
        Deplacement = "R"
    }
    else if(e.keyCode == 40 && Deplacement !="U"){
        Deplacement = "D"
    }
})
function collisionBody(head,snake){
    for (let index = 0; index < snake.length; index++) {
        if(head.x == snake[index].x && head.y ==snake[index].y){
            return true
        }
        
    }
    return false
}
function draw(){
    context.drawImage(background,0,0)
    for (let index = 0; index < snake.length; index++) {
        if(index === 0){
            context.drawImage(snakeHead,snake[index].x,snake[index].y,unit,unit)
        }
        else{
            context.drawImage(snake_body,snake[index].x,snake[index].y,unit,unit)
        }
        
    }

    context.drawImage(foodImg,food.x,food.y,32,32)

    let snakeX = snake[0].x
    let snakeY = snake[0].y

    

    //manger
    if(snakeX == food.x && snakeY == food.y){
        food = {
            x:Math.floor(Math.random() *19+1)*unit,
            y:Math.floor(Math.random() *19+1)*unit
        }
        score +=1
        eatAudio.play()
    }
    else{
        snake.pop()
    }


    if(Deplacement=="L") snakeX -=unit
    if(Deplacement=="U") snakeY -=unit
    if(Deplacement=="R") snakeX +=unit
    if(Deplacement=="D") snakeY +=unit

    let newHead = {
        x:snakeX,
        y:snakeY
    }
    //les collisions
    if(snakeX<=-unit || snakeX>=canvas.width || snakeY<=-unit || snakeY>=canvas.height ||collisionBody(newHead,snake)){
        clearInterval(play)
        boutton.style.display ='block'
        deadAudio.play()
    }
    snake.unshift(newHead)
    scoreSpan.textContent = score
}

const clickButton = () =>{
    window.location.reload()
}
let play = setInterval(draw,150)